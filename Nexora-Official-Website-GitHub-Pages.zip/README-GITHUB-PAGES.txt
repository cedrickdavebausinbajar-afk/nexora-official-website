# Nexora Global Enterprises — GitHub Pages package

This is a static, GitHub Pages-ready copy of the Nexora company website.
It keeps the PulseFit app URL and APK download URL unchanged.

## Publish for free
1. Create a new **public** repository on GitHub (for example `nexora-official-website`).
2. Upload **all files and folders inside this ZIP** to the repository root (not the ZIP itself).
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch **main** and folder **/(root)**, then Save.
6. Wait for GitHub Pages to publish. Your free address will look like:
   `https://YOUR-GITHUB-USERNAME.github.io/nexora-official-website/`

## Important
- This upload package does not change or replace your existing AppDeploy website.
- PulseFit links remain pointed at `https://pulsefit-d3ira0.v2.appdeploy.ai/`.
- APK link remains `https://t.me/cedpulsefitapps/3`.
- The Nexora logo is supplied as an SVG version in `public/resources/`.
- GitHub Pages hosting is free for public repositories, subject to GitHub's current plan limits.
